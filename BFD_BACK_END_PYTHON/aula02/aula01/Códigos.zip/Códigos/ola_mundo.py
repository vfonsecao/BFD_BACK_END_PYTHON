print("Olá, mundo")
# Saída esperada: Olá, mundo
