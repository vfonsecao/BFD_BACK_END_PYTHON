# Entrada de dados
numero_1 = 50
numero_2 = 15

# Saída de dados
print(numero_1 * numero_2)

# Saída esperada: 
# 750